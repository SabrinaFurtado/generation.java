package calcularDiferenca;

public class calculoDiferenca {
    public static void main(String[] args) {

        float n1 = 5.0f;
        float n2 = 6.0f;
        float n3 = 7.0f;
        float n4 = 8.0f;
        
        float diferenca = (n1 * n2) - (n3 * n4);
        
        System.out.println("Diferença: " + diferenca);
    }
}
