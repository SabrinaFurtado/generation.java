package calculoSalario;

public class novoSalario {
	
public static void main(String[] args) {
        
        float salario = 10000;
        float abono = 1000;
        float novoSalario;
      
        novoSalario = salario + abono;

        System.out.println("Novo Salário: " + novoSalario);
    }
}
