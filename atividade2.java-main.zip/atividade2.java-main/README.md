# atividade2.java
atividade java2 do bootcamp da Generation
